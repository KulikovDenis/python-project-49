#!/usr/bin/env python3
import brain_games.brain_code
import brain_games.games.prime


print('Answer "yes" if given number is prime. Otherwise answer "no".')


def main():
    brain_games.games.prime.round()


if __name__ == '__main__':
    main()
