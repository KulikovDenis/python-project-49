#!/usr/bin/env python3
import brain_games.brain_code
import brain_games.games.gcd


print('Find the greatest common divisor of given numbers.')


def main():
    brain_games.games.gcd.round()


if __name__ == '__main__':
    main()