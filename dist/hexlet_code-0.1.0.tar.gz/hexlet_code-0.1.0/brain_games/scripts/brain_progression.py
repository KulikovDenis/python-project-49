#!/usr/bin/env python3
import brain_games.brain_code
import brain_games.games.progression


print('What number is missing in the progression?')


def main():
    brain_games.games.progression.round()


if __name__ == '__main__':
    main()
