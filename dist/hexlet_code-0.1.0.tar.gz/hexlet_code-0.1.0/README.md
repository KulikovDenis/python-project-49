### Hexlet tests and linter status:
[![Actions Status](https://github.com/KulikovDenis/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KulikovDenis/python-project-49/actions)

### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/c707e6ad99e2fd43ad98/maintainability)](https://codeclimate.com/github/KulikovDenis/python-project-49/maintainability)

### Winning the game "Even Check":
[![asciicast](https://asciinema.org/a/603473.svg)](https://asciinema.org/a/603473)

### Lost in the game "Even Check":
[![asciicast](https://asciinema.org/a/603476.svg)](https://asciinema.org/a/603476)

### Winning the game "Calculator":
[![asciicast](https://asciinema.org/a/603636.svg)](https://asciinema.org/a/603636)

### Lost in the game "Calculator":
[![asciicast](https://asciinema.org/a/603637.svg)](https://asciinema.org/a/603637)

### Winning the game "GCD":
[![asciicast](https://asciinema.org/a/603773.svg)](https://asciinema.org/a/603773)

### Lost in the game "GCD":
[![asciicast](https://asciinema.org/a/603774.svg)](https://asciinema.org/a/603774)