### Hexlet tests and linter status:
[![Actions Status](https://github.com/KulikovDenis/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KulikovDenis/python-project-49/actions)

### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/c707e6ad99e2fd43ad98/maintainability)](https://codeclimate.com/github/KulikovDenis/python-project-49/maintainability)