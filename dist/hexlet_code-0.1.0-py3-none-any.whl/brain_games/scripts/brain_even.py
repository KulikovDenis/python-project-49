#!/usr/bin/env python3
import brain_games.brain_even_code
import brain_games.even


def main():
    brain_games.even.raund()


if __name__ == '__main__':
    main()
