#!/usr/bin/env python3
import brain_games.brain_code
import brain_games.games.calc


print('What is the result of the expression?')


def main():
    brain_games.games.calc.round()


if __name__ == '__main__':
    main()